﻿using LessonMVVM.Services;
using LessonMVVM.Commands;
using LessonMVVM.Models;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using MaterialDesignThemes.Wpf;

namespace LessonMVVM.ViewModels.WindowViewModels;
public class EditCarViewModel : NotificationService
{
    public int indexof;
    public ObservableCollection<Car> Cars2 { get; set; }
    private Car? car1;
    public Car? car { get => car1; set { car1 = value; OnPropertyChanged(); } }

    public ObservableCollection<Car> Cars { get; set; }


    public ICommand? SaveCommand { get; set; }
    public ICommand? CancelCommand { get; set; }
    public EditCarViewModel()
    {

    }

    public EditCarViewModel(ObservableCollection<Car> cars, Car newcar,int indexof)
    {
        Cars = cars;
        car = newcar;
        Cars2 = cars;
        SaveCommand = new RelayCommand(Save, CanSave);
        CancelCommand = new RelayCommand(CancelWindow);
        this.indexof = indexof;
    }

    public void CancelWindow(object? parameter)
    {
        var window = parameter as Window;

        if (window != null)
        {
            window.Close();
        }
    }


    public void Save(object? parameter)
    {
        Cars2[indexof] = car!;
        Cars = Cars2;
        car = new();
    }
    public bool CanSave(object? parameter)
    {
        return !string.IsNullOrEmpty(car!.Make) &&
               !string.IsNullOrEmpty(car!.Model) &&
               car.Date != null;
    }

}
