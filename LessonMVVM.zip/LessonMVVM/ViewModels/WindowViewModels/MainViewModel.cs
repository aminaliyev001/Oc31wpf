﻿namespace LessonMVVM.ViewModels.WindowViewModels;

public class MainViewModel
{
}
