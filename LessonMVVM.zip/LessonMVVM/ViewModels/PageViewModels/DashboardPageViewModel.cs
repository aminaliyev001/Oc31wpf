﻿using LessonMVVM.Commands;
using LessonMVVM.Models;
using LessonMVVM.Services;
using LessonMVVM.ViewModels.WindowViewModels;
using LessonMVVM.Views.Windows;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace LessonMVVM.ViewModels.PageViewModels;

public class DashboardPageViewModel : NotificationService
{
    public ObservableCollection<Car> Cars { get; set; }
    public Car curcar;
    public ICommand? AddViewCommand { get; set; }
    public ICommand? EditViewCommand { get; set; }
    public ICommand? RemoveViewCommand { get; set; }
    private Car _selectedCar;
    public Car SelectedCar
    {
        get { return _selectedCar; }
        set
        {
            if (_selectedCar != value)
            {
                _selectedCar = value;
                OnPropertyChanged(nameof(SelectedCar));
            }
        }
    }
    public DashboardPageViewModel()
    {
        Cars = new()
        {
            new("Audi", "Q8", new DateTime(2022, 10, 11)),
            new("Audi", "Q7", new DateTime(2022, 10, 11)),
            new("Hyudai", "Accent", new DateTime(2022, 10, 11)),
            new("Hyudai", "Elantra", new DateTime(2022, 10, 11)),
            new("Kia", "K5", new DateTime(2022, 10, 11)),
        };

        AddViewCommand = new RelayCommand(AddCarView);
        EditViewCommand = new RelayCommand(EditCarView);
        RemoveViewCommand = new RelayCommand(RemoveCarView);
    }

    public void AddCarView(object? parameter)
    {
        var addView = new AddCarView();
        addView.DataContext = new AddCarViewModel(Cars);
        addView.ShowDialog();
    }
    public void EditCarView(object? parameter) 
    {
        if (SelectedCar == null)
            return;
        var indexof = Cars.IndexOf(SelectedCar);
        var editview = new EditCarView();
        editview.DataContext = new EditCarViewModel(Cars, SelectedCar,indexof);
        editview.ShowDialog();
    }
    public void RemoveCarView(object? parameter)
    {
        if (SelectedCar == null)
            return;
        var indexof = Cars.IndexOf(SelectedCar);
        Cars.RemoveAt(indexof);
    }
}
