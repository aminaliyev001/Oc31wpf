﻿using System.Windows;

namespace LessonMVVM.Views.Windows;


public partial class AddCarView : Window
{
    public AddCarView()
    {

        InitializeComponent();
    }
}
